from langchain_community.embeddings import HuggingFaceEmbeddings


class EmbeddingModel:

    def __init__(self):

        self.model = HuggingFaceEmbeddings(
            model_name="sentence-transformers/all-MiniLM-L6-v2"
        )

    def get_model(self):

        return self.model